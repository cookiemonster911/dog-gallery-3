import{a as t}from"../chunks/entry.Cll5SvkE.js";export{t as start};
